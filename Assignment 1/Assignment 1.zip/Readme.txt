CS F363 Compiler Construction Assignment
Phase 1 - Lexical Analysis

Team Details--

# Kumar Pranjal - 2018A7PS0163H
# Ashna Swaika - 2018A7PS0027H
# Abhishek Bapna - 2018A7PS0184H
# Ashish Verma - 2018A7PS0009H

Please run main.py to start the program
